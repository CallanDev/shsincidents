const firebaseConfig = {
  apiKey: "AIzaSyA7xEsYy0IClWdcWc3aYHX_CGU2uoL4inw",
  authDomain: "shs-incidents.firebaseapp.com",
  projectId: "shs-incidents",
  storageBucket: "shs-incidents.firebasestorage.app",
  messagingSenderId: "525936587552",
  appId: "1:525936587552:web:436e95dcf29d8eea5a5d45"
};
firebase.initializeApp(firebaseConfig);
